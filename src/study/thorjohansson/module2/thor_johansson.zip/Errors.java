//package study.thorjohansson.module2;

/**
 * Created by Tjken on 5/14/2017.
 */
//Added class before Errors, and changed e to E
public class Errors{
    //Changed M to m in main
    //Added static before void
    public static void main(String[] args) {
        //Changed s to S in System
        //Changed ' to " since its a string not a char
        System.out.println("Welcome to Java!");
    }
}